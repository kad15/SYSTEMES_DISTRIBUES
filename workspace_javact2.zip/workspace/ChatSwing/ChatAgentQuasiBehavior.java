import org.javact.lang.QuasiBehavior;

public abstract class ChatAgentQuasiBehavior extends QuasiBehavior implements ChatAgent
{
}
