import org.javact.lang.QuasiBehavior;

public abstract class TouriskQuasiBehavior extends QuasiBehavior implements Tourisk
{
}
