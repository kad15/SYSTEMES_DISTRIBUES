package fr.enac.sita.td1.tamagotchi;

public class Tamagotchi {

	private int age = 0;
	private int lifeTime, maxEnergy, energy;
	private String name;

	public Tamagotchi(String name) {
		super();
		this.name = name;
	}

	public String getName() {
		return name;
	}

}
