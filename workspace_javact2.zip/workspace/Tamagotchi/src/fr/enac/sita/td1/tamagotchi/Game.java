package fr.enac.sita.td1.tamagotchi;

public class Game {

	public static void main(String[] args) {
		System.out.println(new Tamagotchi("Pierre").getName());
	}

}
