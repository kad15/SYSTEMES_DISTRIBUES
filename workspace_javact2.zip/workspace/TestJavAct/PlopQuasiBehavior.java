import org.javact.lang.QuasiBehavior;

public abstract class PlopQuasiBehavior extends QuasiBehavior implements Plop
{
}
