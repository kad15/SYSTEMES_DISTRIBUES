import org.javact.lang.QuasiBehavior;

public abstract class MobileChatQuasiBehavior extends QuasiBehavior implements MobileChat
{
}

