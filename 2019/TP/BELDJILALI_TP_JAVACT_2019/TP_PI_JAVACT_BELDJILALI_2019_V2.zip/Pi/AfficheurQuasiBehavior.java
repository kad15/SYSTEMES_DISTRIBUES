import org.javact.lang.QuasiBehavior;

public abstract class AfficheurQuasiBehavior extends QuasiBehavior implements Afficheur
{
}
