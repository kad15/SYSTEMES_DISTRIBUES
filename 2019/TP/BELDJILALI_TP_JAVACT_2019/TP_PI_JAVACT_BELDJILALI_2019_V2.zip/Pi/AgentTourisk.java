import org.javact.util.ActorProfile;

public interface AgentTourisk extends ActorProfile, Recherche, Superviseur, Afficheur {

}