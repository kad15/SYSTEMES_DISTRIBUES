import org.javact.lang.QuasiBehavior;

public abstract class totoQuasiBehavior extends QuasiBehavior implements toto
{
}
