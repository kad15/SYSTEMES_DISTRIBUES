public class JAMsetDest implements org.javact.lang.Message
{
	private int signatureNumber ;


	public JAMsetDest()
	{
		signatureNumber = 0 ;
	}

	public final void handle(org.javact.lang.QuasiBehavior _behavior)
	{
		switch (signatureNumber)
		{
			case 0 :
				if (_behavior instanceof MobileChat)
					((MobileChat) _behavior).setDest() ;
				else 
					throw new org.javact.lang.MessageHandleException() ;
				break ;
			default :
				throw new org.javact.lang.MessageHandleException() ;
		}
	}
}
