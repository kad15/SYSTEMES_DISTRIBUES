import org.javact.util.ActorProfile;
import org.javact.util.BehaviorProfile;

public interface MobileChat extends BehaviorProfile, ActorProfile {
	public void speak();

	public void setDest();
}
