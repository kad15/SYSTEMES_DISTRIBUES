import org.javact.util.BehaviorProfile;

public interface Recherche extends BehaviorProfile {
	public void become(Superviseur beh);

}
