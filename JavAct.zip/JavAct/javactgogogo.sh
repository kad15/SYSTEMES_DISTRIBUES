#!/bin/bash

CMD="~lerichse/startJavActVM $1"
ROOM=d1-203

for ((i = 1; i < 10; i++))
do
	echo "Démarrage sur $ROOM-0$i..."
	ssh $ROOM-0$i "$CMD" &  
done 

for ((i = 10; i <= 22; i++))
do
	echo "Démarrage sur $ROOM-1$i..."
	ssh $ROOM-$i "$CMD" & 
done 



