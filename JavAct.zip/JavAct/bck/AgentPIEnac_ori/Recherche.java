import org.javact.util.ActorProfile;
import org.javact.util.BehaviorProfile;
import org.javact.util.StandAlone;

public interface Recherche extends ActorProfile, BehaviorProfile {

}
