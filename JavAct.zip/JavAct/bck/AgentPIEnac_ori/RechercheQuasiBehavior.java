import org.javact.lang.QuasiBehavior;

public abstract class RechercheQuasiBehavior extends QuasiBehavior implements Recherche
{
}
