import org.javact.util.ActorProfile;

public interface Tourisk extends Recherche, ActorProfile {

}
