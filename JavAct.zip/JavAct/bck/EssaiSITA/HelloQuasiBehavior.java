import org.javact.lang.QuasiBehavior;

public abstract class HelloQuasiBehavior extends QuasiBehavior implements Hello
{
}
