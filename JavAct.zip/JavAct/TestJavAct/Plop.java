import org.javact.util.ActorProfile;
import org.javact.util.BehaviorProfile;

public interface Plop extends BehaviorProfile, ActorProfile {
}
