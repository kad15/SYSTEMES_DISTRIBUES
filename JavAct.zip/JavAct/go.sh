#!/bin/sh
BASE=`pwd`
JAVACT="/home/personnel/SINA/lerichse/javact.jar"
java -Djava.rmi.server.codebase="file:$BASE/" -cp .:$JAVACT Skeleton1 $*
