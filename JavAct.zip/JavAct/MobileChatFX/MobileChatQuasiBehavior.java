package ;

/* Java files from default package can not be imported since  j2sdk 1.4
 * You have to move MobileChat.java into this package or put your file in
 * the default package
*/


import org.javact.lang.QuasiBehavior;

public abstract class MobileChatQuasiBehavior extends QuasiBehavior implements MobileChat
{
}
