import org.javact.util.BehaviorProfile;

public interface Afficheur extends BehaviorProfile {

}
